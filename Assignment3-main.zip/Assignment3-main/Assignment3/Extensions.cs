using System;

namespace BDSA2020.Assignment02
{
    public static class Extensions
    {
    }
}
