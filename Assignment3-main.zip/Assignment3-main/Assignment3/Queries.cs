namespace BDSA2020.Assignment02
{
    public class Queries
    {
    }
}
